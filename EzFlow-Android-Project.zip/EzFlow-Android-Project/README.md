# EzFlow Android

Android Studio project for https://ezflow.ir. Package: `ir.ezflow`; min API 24; compile/target API 34.

Open this folder in Android Studio (JDK 17, Android SDK 34), allow Gradle sync, then Build > Build APK(s). Gradle wrapper scripts are omitted because this environment has no Gradle distribution/wrapper binary; Android Studio can import using its installed Gradle tooling.

Includes Java WebView wrapper, SwipeRefreshLayout, network/offline retry UI, safe SSL failure handling, external URL dispatch, logo-derived mipmap launcher assets and splash drawable.
