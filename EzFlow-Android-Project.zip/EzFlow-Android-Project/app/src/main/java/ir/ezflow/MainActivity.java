package ir.ezflow;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.*;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

public class MainActivity extends AppCompatActivity {
    private static final String HOME = "https://ezflow.ir";
    private SwipeRefreshLayout swipe; private WebView web; private ProgressBar progress;
    private LinearLayout error;
    @SuppressLint("SetJavaScriptEnabled")
    @Override protected void onCreate(Bundle state) { super.onCreate(state);
        getWindow().setStatusBarColor(0xFF123B66); getWindow().setNavigationBarColor(0xFF123B66);
        swipe=new SwipeRefreshLayout(this); swipe.setColorSchemeColors(0xFF1687D9);
        FrameLayout frame=new FrameLayout(this); swipe.addView(frame,new SwipeRefreshLayout.LayoutParams(-1,-1)); setContentView(swipe);
        web=new WebView(this); web.setBackgroundColor(0xFFFFFFFF); web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true); web.getSettings().setDatabaseEnabled(true);
        web.getSettings().setLoadsImagesAutomatically(true); web.getSettings().setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request){return route(request.getUrl());}
            @Override public boolean shouldOverrideUrlLoading(WebView view,String url){return route(Uri.parse(url));}
            private boolean route(Uri uri){String scheme=uri.getScheme(); String host=uri.getHost();
                if ("https".equalsIgnoreCase(scheme) && host!=null && (host.equalsIgnoreCase("ezflow.ir") || host.toLowerCase().endsWith(".ezflow.ir"))) return false;
                if ("http".equalsIgnoreCase(scheme)||"https".equalsIgnoreCase(scheme)||"mailto".equalsIgnoreCase(scheme)||"tel".equalsIgnoreCase(scheme)) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW,uri)); } catch(Exception ignored){} return true;
                } return true; }
            @Override public void onPageStarted(WebView v,String url,Bitmap icon){hideError(); progress.setVisibility(View.VISIBLE); swipe.setRefreshing(false);}
            @Override public void onPageFinished(WebView v,String url){progress.setVisibility(View.GONE);swipe.setRefreshing(false);}
            @Override public void onReceivedError(WebView v,WebResourceRequest r,WebResourceError e){if(r.isForMainFrame()) showError();}
            @Override public void onReceivedSslError(WebView v,SslErrorHandler h,android.net.http.SslError e){h.cancel();showError();}
        });
        web.setWebChromeClient(new WebChromeClient(){@Override public void onProgressChanged(WebView v,int p){progress.setProgress(p);progress.setVisibility(p>=100?View.GONE:View.VISIBLE);}
            @Override public void onReceivedTitle(WebView v,String title){if(title!=null&&!title.trim().isEmpty())setTitle(title);}});
        frame.addView(web,new FrameLayout.LayoutParams(-1,-1)); progress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100); FrameLayout.LayoutParams pp=new FrameLayout.LayoutParams(-1,6,Gravity.TOP); frame.addView(progress,pp);
        error=new LinearLayout(this);error.setGravity(Gravity.CENTER);error.setOrientation(LinearLayout.VERTICAL);error.setBackgroundColor(0xFFFFFFFF);
        TextView msg=new TextView(this);msg.setText("اتصال به اینترنت برقرار نیست یا بارگذاری ناموفق بود.");msg.setTextColor(0xFF333333);msg.setGravity(Gravity.CENTER); error.addView(msg);
        Button retry=new Button(this);retry.setText("تلاش دوباره");retry.setOnClickListener(v->web.reload());error.addView(retry);
        FrameLayout.LayoutParams ep=new FrameLayout.LayoutParams(-1,-1);frame.addView(error,ep);error.setVisibility(View.GONE);
        swipe.setOnRefreshListener(()->{if(error.getVisibility()==View.VISIBLE)web.loadUrl(HOME);else web.reload();});
        if(state!=null)web.restoreState(state);else web.loadUrl(HOME);
    }
    private void showError(){progress.setVisibility(View.GONE);swipe.setRefreshing(false);error.setVisibility(View.VISIBLE);}
    private void hideError(){if(error!=null)error.setVisibility(View.GONE);}
    @Override protected void onSaveInstanceState(Bundle out){web.saveState(out);super.onSaveInstanceState(out);}
    @Override public void onBackPressed(){if(web!=null&&web.canGoBack())web.goBack();else super.onBackPressed();}
    @Override protected void onDestroy(){if(web!=null){web.destroy();web=null;}super.onDestroy();}
}
